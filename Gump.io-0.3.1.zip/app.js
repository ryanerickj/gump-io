(() => {
  // src/main.ts
  var $ = (id) => document.getElementById(id);
  var fileInput = $("file");
  var video = $("video");
  var meta = $("meta");
  var status = $("status");
  var progress = $("progress").firstElementChild;
  var controls = $("controls");
  var specific = $("specific");
  var results = $("results");
  var grid = $("grid");
  var count = $("count");
  var interval = $("interval");
  var start = $("start");
  var end = $("end");
  var maxframes = $("maxframes");
  var scanInfo = $("scaninfo");
  var groupStatus = $("group-status");
  var previewModal = $("preview-modal");
  var previewImage = $("preview-image");
  var previewCaption = $("preview-caption");
  var dropZone = $("drop-zone");
  var order = $("order");
  var file = null;
  var objectUrl = null;
  var frames = [];
  var cancelled = false;
  var busy = false;
  var previewFrame = null;
  function timeLabel(value) {
    const h = Math.floor(value / 3600), m = Math.floor(value % 3600 / 60), s = Math.floor(value % 60);
    return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
  }
  function safeName(value) {
    return value.replace(/\.[^.]+$/, "").replace(/[\\/:*?"<>|]+/g, "-").slice(0, 80) || "frame";
  }
  function setProgress(value) {
    progress.style.width = value === null ? "0" : `${value}%`;
  }
  function event(name, max = 15000) {
    return new Promise((resolve, reject) => {
      const done = () => {
        clearTimeout(timer);
        video.removeEventListener(name, done);
        resolve();
      };
      const timer = setTimeout(() => {
        video.removeEventListener(name, done);
        reject(new Error("O vídeo demorou demais para responder."));
      }, max);
      video.addEventListener(name, done, { once: true });
    });
  }
  function parseTime(value) {
    const clean = value.trim();
    if (!clean)
      return null;
    const parts = clean.split(":").map(Number);
    if (parts.length > 3 || parts.some((n) => !Number.isFinite(n) || n < 0))
      return null;
    return parts.reduce((total, part) => total * 60 + part, 0);
  }
  function scanRange() {
    const duration = video.duration;
    const from = parseTime(start.value) ?? 0, requestedEnd = parseTime(end.value);
    const to = requestedEnd == null ? duration : requestedEnd;
    const every = Math.max(1, Number(interval.value) || 15), limit = Math.min(1200, Math.max(1, Math.floor(Number(maxframes.value) || 600)));
    if (!Number.isFinite(duration) || from >= duration || to <= from)
      return null;
    const last = Math.min(duration - 0.04, to);
    const total = Math.ceil((last - from) / every);
    const actual = Math.min(total, limit);
    return { from, last, every, total, actual, capped: total > limit };
  }
  function updateScanInfo() {
    const range = scanRange();
    if (!range) {
      scanInfo.textContent = "Defina um intervalo válido dentro do vídeo.";
      return;
    }
    scanInfo.textContent = range.capped ? `${range.total} frames possíveis; serão capturados ${range.actual} distribuídos de ${timeLabel(range.from)} a ${timeLabel(range.last)}.` : `${range.actual} frames de ${timeLabel(range.from)} a ${timeLabel(range.last)}.`;
  }
  function scanTimes() {
    const range = scanRange();
    if (!range)
      return [];
    if (!range.capped)
      return Array.from({ length: range.actual }, (_, i) => Math.min(range.last, range.from + i * range.every));
    const span = range.last - range.from;
    return Array.from({ length: range.actual }, (_, i) => range.from + i * span / Math.max(1, range.actual - 1));
  }
  async function seek(time) {
    const target = Math.max(0, Math.min(time, video.duration - 0.04));
    if (Math.abs(video.currentTime - target) < 0.04)
      return;
    const ready = event("seeked");
    video.currentTime = target;
    await ready;
  }
  function canvas(maxWidth) {
    const scale = maxWidth ? Math.min(1, maxWidth / video.videoWidth) : 1;
    const c = document.createElement("canvas");
    c.width = Math.round(video.videoWidth * scale);
    c.height = Math.round(video.videoHeight * scale);
    c.getContext("2d").drawImage(video, 0, 0, c.width, c.height);
    return c;
  }
  function sharpness(c) {
    const d = c.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, c.width, c.height).data;
    let total = 0, n = 0;
    for (let y = 1;y < c.height - 1; y += 4)
      for (let x = 1;x < c.width - 1; x += 4) {
        const i = (y * c.width + x) * 4, r = i + 4, b = i + c.width * 4;
        const l = (j) => 0.2126 * d[j] + 0.7152 * d[j + 1] + 0.0722 * d[j + 2];
        total += Math.abs(l(i) - l(r)) + Math.abs(l(i) - l(b));
        n++;
      }
    return Math.round(Math.min(100, total / Math.max(1, n) * 1.6));
  }
  var faceRuntime = null;
  async function getFaceRuntime() {
    if (faceRuntime)
      return faceRuntime;
    faceRuntime = (async () => {
      const vision = await import(chrome.runtime.getURL("vendor/vision_bundle.mjs"));
      const files = await vision.FilesetResolver.forVisionTasks(chrome.runtime.getURL("wasm"));
      return vision.FaceLandmarker.createFromOptions(files, { baseOptions: { modelAssetPath: chrome.runtime.getURL("models/face_landmarker.task") }, runningMode: "IMAGE", numFaces: 1, outputFaceBlendshapes: true });
    })();
    return faceRuntime;
  }
  function score(categories, name) {
    return categories?.find((c) => c.categoryName === name)?.score ?? 0;
  }
  async function groupFrames() {
    if (!frames.length || busy)
      return;
    busy = true;
    groupStatus.textContent = "Carregando análise facial local…";
    try {
      const runtime = await getFaceRuntime();
      const grouped = { Sorrindo: 0, "Rosto de lado": 0, "Close / rosto": 0, "Plano amplo / sem rosto": 0, Outros: 0 };
      for (let i = 0;i < frames.length; i++) {
        const frame = frames[i];
        const bitmap = await createImageBitmap(await (await fetch(frame.preview)).blob());
        const out = runtime.detect(bitmap), landmarks = out.faceLandmarks?.[0], cats = out.faceBlendshapes?.[0]?.categories;
        bitmap.close();
        let group = "Plano amplo / sem rosto";
        if (landmarks?.length) {
          const xs = landmarks.map((p) => p.x), ys = landmarks.map((p) => p.y), area = (Math.max(...xs) - Math.min(...xs)) * (Math.max(...ys) - Math.min(...ys));
          const left = landmarks[33], right = landmarks[263], nose = landmarks[1];
          const midpoint = (left.x + right.x) / 2, eyeSpan = Math.abs(right.x - left.x) || 0.01;
          const yaw = Math.abs((nose.x - midpoint) / eyeSpan);
          const smile = (score(cats, "mouthSmileLeft") + score(cats, "mouthSmileRight")) / 2;
          group = smile > 0.35 ? "Sorrindo" : yaw > 0.18 ? "Rosto de lado" : area > 0.13 ? "Close / rosto" : "Outros";
        }
        frame.group = group;
        grouped[group]++;
        groupStatus.textContent = `Analisando ${i + 1}/${frames.length} frames…`;
      }
      render();
      groupStatus.textContent = `Agrupamento local concluído: ${Object.entries(grouped).filter(([, n]) => n).map(([k, n]) => `${k}: ${n}`).join(" · ")}.`;
    } catch (error) {
      faceRuntime = null;
      groupStatus.textContent = `Não foi possível carregar o analisador local: ${error instanceof Error ? error.message : "erro desconhecido"}.`;
    } finally {
      busy = false;
    }
  }
  function orderedFrames() {
    const mode = order.value;
    return [...frames].sort((a, b) => mode === "time" ? a.time - b.time : mode === "reverse-time" ? b.time - a.time : b.sharpness - a.sharpness);
  }
  function render() {
    const sorted = orderedFrames();
    results.hidden = !frames.length;
    count.textContent = `${frames.length} candidatos · ${order.options[order.selectedIndex].text.toLocaleLowerCase()}`;
    grid.replaceChildren(...sorted.map((f) => {
      const card = document.createElement("div");
      card.className = "frame";
      card.innerHTML = `<img src="${f.preview}" alt="Frame em ${timeLabel(f.time)}"><label><input type="checkbox" data-id="${f.id}"> ${timeLabel(f.time)} <em>Nitidez ${f.sharpness}</em></label>${f.group ? `<span class="group-label">${f.group}</span>` : ""}<div class="frame-actions"><button class="secondary frame-download" title="Baixar PNG em resolução nativa" aria-label="Baixar frame em alta">⇩ PNG</button><button class="secondary frame-copy" title="Copiar PNG em resolução nativa" aria-label="Copiar frame em alta">⧉ Copiar</button></div>`;
      card.querySelector("img").addEventListener("click", () => void openPreview(f));
      card.querySelector(".frame-download").addEventListener("click", () => void downloadFrame(f));
      card.querySelector(".frame-copy").addEventListener("click", () => void copyFrame(f));
      return card;
    }));
  }
  async function openPreview(frame) {
    if (!file || busy)
      return;
    previewFrame = frame;
    previewImage.src = frame.preview;
    previewImage.alt = `Preview ampliado — ${timeLabel(frame.time)}`;
    previewCaption.textContent = `Carregando preview em alta · ${timeLabel(frame.time)}`;
    previewModal.showModal();
    try {
      await seek(frame.time);
      const maxPreview = Math.min(2560, video.videoWidth);
      previewImage.src = canvas(maxPreview).toDataURL("image/jpeg", 0.96);
      previewCaption.textContent = `${timeLabel(frame.time)} · ${Math.min(video.videoWidth, 2560)} px · Nitidez ${frame.sharpness}${frame.group ? ` · ${frame.group}` : ""}`;
    } catch {
      previewCaption.textContent = `${timeLabel(frame.time)} · preview rápido`;
    }
  }
  async function navigatePreview(direction) {
    if (!previewFrame)
      return;
    const list = orderedFrames(), at = list.findIndex((frame) => frame.id === previewFrame.id), next = list[at + direction];
    if (!next)
      return;
    await openPreview(next);
  }
  async function nativePng(frame) {
    await seek(frame.time);
    const c = canvas();
    return new Promise((resolve, reject) => c.toBlob((b) => b ? resolve(b) : reject(new Error("PNG indisponível.")), "image/png"));
  }
  async function downloadFrame(frame) {
    if (!file || busy)
      return;
    busy = true;
    try {
      status.textContent = `Preparando PNG em alta (${timeLabel(frame.time)})…`;
      const blob = await nativePng(frame), url = URL.createObjectURL(blob), a = document.createElement("a");
      a.href = url;
      a.download = `${safeName(file.name)}-${timeLabel(frame.time).replaceAll(":", "-")}.png`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1e4);
      status.textContent = "PNG em resolução nativa baixado.";
    } catch (error) {
      status.textContent = error instanceof Error ? error.message : "Falha ao baixar o PNG.";
    } finally {
      busy = false;
    }
  }
  async function copyFrame(frame) {
    if (!file || busy)
      return;
    busy = true;
    try {
      status.textContent = `Copiando PNG em alta (${timeLabel(frame.time)})…`;
      const blob = await nativePng(frame);
      if (!navigator.clipboard?.write || typeof ClipboardItem === "undefined")
        throw new Error("Seu Chrome não oferece cópia de imagem nesta página. Use o botão PNG.");
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
      status.textContent = "PNG em resolução nativa copiado para a área de transferência.";
    } catch (error) {
      status.textContent = error instanceof Error ? error.message : "Falha ao copiar o PNG.";
    } finally {
      busy = false;
    }
  }
  async function capture(times, replace = false) {
    if (!file || busy)
      return;
    const valid = [...new Set(times.map((t) => Math.max(0, Math.min(t, video.duration - 0.04))))].sort((a, b) => a - b);
    if (!valid.length) {
      status.textContent = "Informe timestamps válidos dentro da duração do vídeo.";
      return;
    }
    busy = true;
    cancelled = false;
    const out = [];
    try {
      for (let i = 0;i < valid.length && !cancelled; i++) {
        await seek(valid[i]);
        const small = canvas(640);
        out.push({ id: `${Math.round(valid[i] * 1000)}-${i}`, time: valid[i], preview: small.toDataURL("image/jpeg", 0.84), sharpness: sharpness(small) });
        setProgress((i + 1) / valid.length * 100);
        status.textContent = `Analisando ${i + 1} de ${valid.length} frames…`;
      }
      frames = replace ? out : [...frames, ...out];
      render();
      status.textContent = cancelled ? "Varredura cancelada." : `${out.length} frames capturados. Selecione os melhores para baixar PNGs em resolução nativa.`;
    } catch (e) {
      status.textContent = e instanceof Error ? e.message : "A varredura falhou.";
    } finally {
      busy = false;
      setProgress(null);
    }
  }
  async function loadVideo(next) {
    if (!next.type.startsWith("video/")) {
      status.textContent = "Selecione ou solte um arquivo de vídeo válido.";
      return;
    }
    if (objectUrl)
      URL.revokeObjectURL(objectUrl);
    file = next;
    objectUrl = URL.createObjectURL(next);
    frames = [];
    render();
    status.textContent = "Abrindo arquivo local…";
    video.src = objectUrl;
    try {
      await event("loadedmetadata");
      meta.textContent = `${file.name} · ${timeLabel(video.duration)} · ${video.videoWidth}×${video.videoHeight}`;
      controls.hidden = false;
      specific.hidden = false;
      updateScanInfo();
      status.textContent = "Pronto. O arquivo permanece somente neste navegador.";
    } catch (e) {
      status.textContent = e instanceof Error ? e.message : "Não foi possível abrir o vídeo.";
    }
  }
  fileInput.addEventListener("change", () => {
    const next = fileInput.files?.[0];
    fileInput.value = "";
    if (next)
      loadVideo(next);
  });
  ["dragenter", "dragover"].forEach((name) => dropZone.addEventListener(name, (event2) => {
    event2.preventDefault();
    dropZone.classList.add("dragging");
  }));
  ["dragleave", "drop"].forEach((name) => dropZone.addEventListener(name, (event2) => {
    event2.preventDefault();
    dropZone.classList.remove("dragging");
  }));
  dropZone.addEventListener("drop", (event2) => {
    const next = event2.dataTransfer?.files?.[0];
    if (next)
      loadVideo(next);
  });
  order.addEventListener("change", render);
  [start, end, interval, maxframes].forEach((input) => input.addEventListener("input", updateScanInfo));
  document.querySelectorAll("[data-interval]").forEach((button) => button.addEventListener("click", () => {
    interval.value = button.dataset.interval;
    updateScanInfo();
  }));
  $("scan").addEventListener("click", () => {
    const times = scanTimes();
    if (!times.length) {
      status.textContent = "Defina início e fim válidos para a varredura.";
      return;
    }
    capture(times, true);
  });
  $("capture").addEventListener("click", () => {
    const parsed = timestamps.value.split(/[\s,;]+/).filter(Boolean).map(parseTime).filter((v) => v !== null);
    capture(parsed);
  });
  $("cancel").addEventListener("click", () => {
    cancelled = true;
    status.textContent = "Cancelando após o frame atual…";
  });
  $("group").addEventListener("click", () => void groupFrames());
  $("close-preview").addEventListener("click", () => previewModal.close());
  $("preview-previous").addEventListener("click", () => void navigatePreview(-1));
  $("preview-next").addEventListener("click", () => void navigatePreview(1));
  document.addEventListener("keydown", (event2) => {
    if (!previewModal.open)
      return;
    if (event2.key === "ArrowLeft") {
      event2.preventDefault();
      navigatePreview(-1);
    }
    if (event2.key === "ArrowRight") {
      event2.preventDefault();
      navigatePreview(1);
    }
  });
  $("preview-download").addEventListener("click", () => {
    if (previewFrame)
      downloadFrame(previewFrame);
  });
  $("preview-copy").addEventListener("click", () => {
    if (previewFrame)
      copyFrame(previewFrame);
  });
  previewModal.addEventListener("click", (event2) => {
    if (event2.target === previewModal)
      previewModal.close();
  });
  $("export").addEventListener("click", async () => {
    const chosen = frames.filter((f) => grid.querySelector(`[data-id="${f.id}"]`)?.checked).sort((a, b) => a.time - b.time);
    if (!chosen.length) {
      status.textContent = "Selecione ao menos um frame.";
      return;
    }
    busy = true;
    cancelled = false;
    try {
      for (let i = 0;i < chosen.length && !cancelled; i++) {
        await seek(chosen[i].time);
        const c = canvas();
        const blob = await new Promise((resolve, reject) => c.toBlob((b) => b ? resolve(b) : reject(new Error("PNG indisponível.")), "image/png"));
        const url = URL.createObjectURL(blob), a = document.createElement("a");
        a.href = url;
        a.download = `${safeName(file.name)}-${timeLabel(chosen[i].time).replaceAll(":", "-")}.png`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 1e4);
        setProgress((i + 1) / chosen.length * 100);
        status.textContent = `Exportando ${i + 1} de ${chosen.length} PNGs…`;
      }
    } catch (e) {
      status.textContent = e instanceof Error ? e.message : "A exportação falhou.";
    } finally {
      busy = false;
      setProgress(null);
      if (!cancelled)
        status.textContent = "PNGs exportados na resolução nativa do vídeo.";
    }
  });
})();
